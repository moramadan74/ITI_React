export default function protfilo(props){
    return<>
    <div className="portapp">
        
                    <h3>{props.name}</h3>
                    
                    
                </div>
                </>
}