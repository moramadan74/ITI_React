export default function proskills(props){
    return<>
     <div>
        <button id="hoppy-btn">{props.name}</button><input id="inputvaled"></input></div>
    
    </>
}