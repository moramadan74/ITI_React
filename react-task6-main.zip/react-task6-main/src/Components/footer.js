 import React from "react";

import FacebookLogo from "./assets/facebooklogo";
 

export default function footer(){
    return<>
    <div className="mangerfooter">
    <div className="mainfooter">
        <h4>
            GET IN TOUCH!
        </h4>
        <p>tarneem@gmail.com</p>
      

    </div>
    <button id="conbtn">CONTACT US</button>
    <div className="mainfooter">
      <FacebookLogo />
      
       
        

    </div>
    </div>
    </>
}
 
 