import "./style.css";

export default function nav(){
    return<>
     <div className="container">
       
         <h1>Tarnnem Magdy</h1>
    <h2>Web Develper & Designer</h2>
    
         <button  className="button">Contact me</button>
       </div>
    </>
}
