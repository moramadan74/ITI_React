import "./about.css";

export default function about(){
    return <>
    <div className="About">
        <div className="aboutClass">
            <h1>About..Me</h1>

        </div>
        <div className="text">
            <h5>You’ve just graduated and you’re ready to take on the world. But where do you start? The Job Search of course and that one document that can make or break your chances of Landing you your dream Job is your Resume, CV, and Cover Letter. Download Fully Editable Sample Now below. Our professional Resume Designs are proven to land interviews. Download free Resume/CV and Cover Letter Templates.

Take a peek at our database that contains Resume Templates. Pick an illustration that not only fits your personal taste but also illustrates the kind of work you would like to do in the future. Every one of these Resume Templates is produced in Microsoft Word format   We have a large number of ideas that are already in usable form. Utilize any one of our ready examples!</h5>
                 <button className="btn">Download paraphrase</button>
        </div>
       
    </div>
    
    </>
}